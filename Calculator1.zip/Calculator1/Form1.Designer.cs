﻿namespace Calculator1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.richTxtBox1 = new System.Windows.Forms.RichTextBox();
            this.btn6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn13 = new System.Windows.Forms.Button();
            this.btn14 = new System.Windows.Forms.Button();
            this.btn15 = new System.Windows.Forms.Button();
            this.btn16 = new System.Windows.Forms.Button();
            this.btn17 = new System.Windows.Forms.Button();
            this.btn18 = new System.Windows.Forms.Button();
            this.btn19 = new System.Windows.Forms.Button();
            this.btn20 = new System.Windows.Forms.Button();
            this.btn21 = new System.Windows.Forms.Button();
            this.btn22 = new System.Windows.Forms.Button();
            this.btn23 = new System.Windows.Forms.Button();
            this.btn24 = new System.Windows.Forms.Button();
            this.btn25 = new System.Windows.Forms.Button();
            this.btn26 = new System.Windows.Forms.Button();
            this.btn27 = new System.Windows.Forms.Button();
            this.MinusPlusbtn = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewToolStripMenuItem,
            this.editToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(484, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(12, 24);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(47, 24);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
            this.copyToolStripMenuItem.Text = "Copy";
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
            this.pasteToolStripMenuItem.Text = "Paste";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(119, 24);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // richTxtBox1
            // 
            this.richTxtBox1.Location = new System.Drawing.Point(22, 50);
            this.richTxtBox1.Margin = new System.Windows.Forms.Padding(4);
            this.richTxtBox1.Name = "richTxtBox1";
            this.richTxtBox1.Size = new System.Drawing.Size(423, 117);
            this.richTxtBox1.TabIndex = 1;
            this.richTxtBox1.Text = "";
            this.richTxtBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // btn6
            // 
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.Location = new System.Drawing.Point(401, 223);
            this.btn6.Margin = new System.Windows.Forms.Padding(4);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(65, 52);
            this.btn6.TabIndex = 11;
            this.btn6.Text = "√";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(308, 466);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(74, 52);
            this.button7.TabIndex = 10;
            this.button7.Text = "-";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // btn8
            // 
            this.btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.Location = new System.Drawing.Point(217, 223);
            this.btn8.Margin = new System.Windows.Forms.Padding(4);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(65, 52);
            this.btn8.TabIndex = 9;
            this.btn8.Text = "C";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btn9
            // 
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.Location = new System.Drawing.Point(124, 223);
            this.btn9.Margin = new System.Windows.Forms.Padding(4);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(65, 52);
            this.btn9.TabIndex = 8;
            this.btn9.Text = "CE";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.button9_Click);
            // 
            // btn10
            // 
            this.btn10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn10.Location = new System.Drawing.Point(33, 223);
            this.btn10.Margin = new System.Windows.Forms.Padding(4);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(65, 52);
            this.btn10.TabIndex = 7;
            this.btn10.Text = "<=";
            this.btn10.UseVisualStyleBackColor = true;
            this.btn10.Click += new System.EventHandler(this.button10_Click);
            // 
            // btn11
            // 
            this.btn11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn11.Location = new System.Drawing.Point(401, 305);
            this.btn11.Margin = new System.Windows.Forms.Padding(4);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(65, 52);
            this.btn11.TabIndex = 16;
            this.btn11.Text = "x*x";
            this.btn11.UseVisualStyleBackColor = true;
            this.btn11.Click += new System.EventHandler(this.button11_Click);
            // 
            // btn12
            // 
            this.btn12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn12.Location = new System.Drawing.Point(308, 302);
            this.btn12.Margin = new System.Windows.Forms.Padding(4);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(74, 58);
            this.btn12.TabIndex = 15;
            this.btn12.Text = "/";
            this.btn12.UseVisualStyleBackColor = true;
            this.btn12.Click += new System.EventHandler(this.button12_Click);
            // 
            // btn13
            // 
            this.btn13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn13.Location = new System.Drawing.Point(217, 299);
            this.btn13.Margin = new System.Windows.Forms.Padding(4);
            this.btn13.Name = "btn13";
            this.btn13.Size = new System.Drawing.Size(65, 58);
            this.btn13.TabIndex = 14;
            this.btn13.Text = "9";
            this.btn13.UseVisualStyleBackColor = true;
            this.btn13.Click += new System.EventHandler(this.button13_Click);
            // 
            // btn14
            // 
            this.btn14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn14.Location = new System.Drawing.Point(124, 299);
            this.btn14.Margin = new System.Windows.Forms.Padding(4);
            this.btn14.Name = "btn14";
            this.btn14.Size = new System.Drawing.Size(65, 61);
            this.btn14.TabIndex = 13;
            this.btn14.Text = "8";
            this.btn14.UseVisualStyleBackColor = true;
            this.btn14.Click += new System.EventHandler(this.button14_Click);
            // 
            // btn15
            // 
            this.btn15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn15.Location = new System.Drawing.Point(33, 302);
            this.btn15.Margin = new System.Windows.Forms.Padding(4);
            this.btn15.Name = "btn15";
            this.btn15.Size = new System.Drawing.Size(65, 58);
            this.btn15.TabIndex = 12;
            this.btn15.Text = "7";
            this.btn15.UseVisualStyleBackColor = true;
            this.btn15.Click += new System.EventHandler(this.button15_Click);
            // 
            // btn16
            // 
            this.btn16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn16.Location = new System.Drawing.Point(401, 388);
            this.btn16.Margin = new System.Windows.Forms.Padding(4);
            this.btn16.Name = "btn16";
            this.btn16.Size = new System.Drawing.Size(65, 52);
            this.btn16.TabIndex = 21;
            this.btn16.Text = "1/X";
            this.btn16.UseVisualStyleBackColor = true;
            this.btn16.Click += new System.EventHandler(this.button16_Click);
            // 
            // btn17
            // 
            this.btn17.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn17.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn17.Location = new System.Drawing.Point(308, 381);
            this.btn17.Margin = new System.Windows.Forms.Padding(4);
            this.btn17.Name = "btn17";
            this.btn17.Size = new System.Drawing.Size(74, 59);
            this.btn17.TabIndex = 20;
            this.btn17.Text = "*";
            this.btn17.UseVisualStyleBackColor = true;
            this.btn17.Click += new System.EventHandler(this.button17_Click);
            // 
            // btn18
            // 
            this.btn18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn18.Location = new System.Drawing.Point(217, 374);
            this.btn18.Margin = new System.Windows.Forms.Padding(4);
            this.btn18.Name = "btn18";
            this.btn18.Size = new System.Drawing.Size(65, 59);
            this.btn18.TabIndex = 19;
            this.btn18.Text = "6";
            this.btn18.UseVisualStyleBackColor = true;
            this.btn18.Click += new System.EventHandler(this.button18_Click);
            // 
            // btn19
            // 
            this.btn19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn19.Location = new System.Drawing.Point(124, 374);
            this.btn19.Margin = new System.Windows.Forms.Padding(4);
            this.btn19.Name = "btn19";
            this.btn19.Size = new System.Drawing.Size(65, 59);
            this.btn19.TabIndex = 18;
            this.btn19.Text = "5";
            this.btn19.UseVisualStyleBackColor = true;
            this.btn19.Click += new System.EventHandler(this.button19_Click);
            // 
            // btn20
            // 
            this.btn20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn20.Location = new System.Drawing.Point(33, 374);
            this.btn20.Margin = new System.Windows.Forms.Padding(4);
            this.btn20.Name = "btn20";
            this.btn20.Size = new System.Drawing.Size(65, 59);
            this.btn20.TabIndex = 17;
            this.btn20.Text = "4";
            this.btn20.UseVisualStyleBackColor = true;
            this.btn20.Click += new System.EventHandler(this.button20_Click);
            // 
            // btn21
            // 
            this.btn21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn21.Location = new System.Drawing.Point(401, 466);
            this.btn21.Margin = new System.Windows.Forms.Padding(4);
            this.btn21.Name = "btn21";
            this.btn21.Size = new System.Drawing.Size(70, 149);
            this.btn21.TabIndex = 26;
            this.btn21.Text = "=";
            this.btn21.UseVisualStyleBackColor = true;
            this.btn21.Click += new System.EventHandler(this.button21_Click);
            // 
            // btn22
            // 
            this.btn22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn22.Location = new System.Drawing.Point(308, 536);
            this.btn22.Margin = new System.Windows.Forms.Padding(4);
            this.btn22.Name = "btn22";
            this.btn22.Size = new System.Drawing.Size(74, 61);
            this.btn22.TabIndex = 25;
            this.btn22.Text = "+";
            this.btn22.UseVisualStyleBackColor = true;
            this.btn22.Click += new System.EventHandler(this.button22_Click);
            // 
            // btn23
            // 
            this.btn23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn23.Location = new System.Drawing.Point(217, 449);
            this.btn23.Margin = new System.Windows.Forms.Padding(4);
            this.btn23.Name = "btn23";
            this.btn23.Size = new System.Drawing.Size(65, 61);
            this.btn23.TabIndex = 24;
            this.btn23.Text = "3";
            this.btn23.UseVisualStyleBackColor = true;
            this.btn23.Click += new System.EventHandler(this.button23_Click);
            // 
            // btn24
            // 
            this.btn24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn24.Location = new System.Drawing.Point(124, 449);
            this.btn24.Margin = new System.Windows.Forms.Padding(4);
            this.btn24.Name = "btn24";
            this.btn24.Size = new System.Drawing.Size(65, 61);
            this.btn24.TabIndex = 23;
            this.btn24.Text = "2";
            this.btn24.UseVisualStyleBackColor = true;
            this.btn24.Click += new System.EventHandler(this.button24_Click);
            // 
            // btn25
            // 
            this.btn25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn25.Location = new System.Drawing.Point(33, 449);
            this.btn25.Margin = new System.Windows.Forms.Padding(4);
            this.btn25.Name = "btn25";
            this.btn25.Size = new System.Drawing.Size(65, 61);
            this.btn25.TabIndex = 22;
            this.btn25.Text = "1";
            this.btn25.UseVisualStyleBackColor = true;
            this.btn25.Click += new System.EventHandler(this.button25_Click);
            // 
            // btn26
            // 
            this.btn26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn26.Location = new System.Drawing.Point(33, 531);
            this.btn26.Margin = new System.Windows.Forms.Padding(4);
            this.btn26.Name = "btn26";
            this.btn26.Size = new System.Drawing.Size(167, 66);
            this.btn26.TabIndex = 27;
            this.btn26.Text = "0";
            this.btn26.UseVisualStyleBackColor = true;
            this.btn26.Click += new System.EventHandler(this.button26_Click);
            // 
            // btn27
            // 
            this.btn27.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn27.Location = new System.Drawing.Point(217, 531);
            this.btn27.Margin = new System.Windows.Forms.Padding(4);
            this.btn27.Name = "btn27";
            this.btn27.Size = new System.Drawing.Size(74, 60);
            this.btn27.TabIndex = 28;
            this.btn27.Text = ".";
            this.btn27.UseVisualStyleBackColor = true;
            this.btn27.Click += new System.EventHandler(this.button27_Click);
            // 
            // MinusPlusbtn
            // 
            this.MinusPlusbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinusPlusbtn.Location = new System.Drawing.Point(317, 223);
            this.MinusPlusbtn.Margin = new System.Windows.Forms.Padding(4);
            this.MinusPlusbtn.Name = "MinusPlusbtn";
            this.MinusPlusbtn.Size = new System.Drawing.Size(65, 52);
            this.MinusPlusbtn.TabIndex = 5;
            this.MinusPlusbtn.Text = "+/-";
            this.MinusPlusbtn.UseVisualStyleBackColor = true;
            this.MinusPlusbtn.Click += new System.EventHandler(this.MinusPlusBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 631);
            this.Controls.Add(this.btn27);
            this.Controls.Add(this.btn26);
            this.Controls.Add(this.btn21);
            this.Controls.Add(this.btn22);
            this.Controls.Add(this.btn23);
            this.Controls.Add(this.btn24);
            this.Controls.Add(this.btn25);
            this.Controls.Add(this.btn16);
            this.Controls.Add(this.btn17);
            this.Controls.Add(this.btn18);
            this.Controls.Add(this.btn19);
            this.Controls.Add(this.btn20);
            this.Controls.Add(this.btn11);
            this.Controls.Add(this.btn12);
            this.Controls.Add(this.btn13);
            this.Controls.Add(this.btn14);
            this.Controls.Add(this.btn15);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn10);
            this.Controls.Add(this.MinusPlusbtn);
            this.Controls.Add(this.richTxtBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.RichTextBox richTxtBox1;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn12;
        private System.Windows.Forms.Button btn13;
        private System.Windows.Forms.Button btn14;
        private System.Windows.Forms.Button btn15;
        private System.Windows.Forms.Button btn16;
        private System.Windows.Forms.Button btn17;
        private System.Windows.Forms.Button btn18;
        private System.Windows.Forms.Button btn19;
        private System.Windows.Forms.Button btn20;
        private System.Windows.Forms.Button btn21;
        private System.Windows.Forms.Button btn22;
        private System.Windows.Forms.Button btn23;
        private System.Windows.Forms.Button btn24;
        private System.Windows.Forms.Button btn25;
        private System.Windows.Forms.Button btn26;
        private System.Windows.Forms.Button btn27;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.Button MinusPlusbtn;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
    }
}